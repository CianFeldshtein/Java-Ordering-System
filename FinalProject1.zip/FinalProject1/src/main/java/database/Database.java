package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Database {

	private static Connection con;
	private static Database database;

	private Database() {

		try {
			con = DriverManager.getConnection("jdbc:mysql://127.0.0.1/test?useSSL=false", "root", "");
			System.out.println("Success");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Database getInstance() {

		if (database == null)
			database = new Database();

		return database;
	}

	public static Connection getConnection() {

		return con;
	}

	public static boolean insert(String statement) {

		try {

			Statement state = con.createStatement();
			int result = state.executeUpdate(statement);
			System.out.println("The Number or records inserted is: " + result);
			state.close();
			return true;

		} catch (Exception io) {
			io.printStackTrace();
			}
			return false;
		}

	public static ResultSet queryStatement(String qry) {
		
		ResultSet rs = null;
		
		try {
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery(qry);

			
		} catch (Exception io) {
			io.printStackTrace();
		}
		
		return rs;
	}
}
